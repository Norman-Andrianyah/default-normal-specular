* CopyRight © 2020 Norman Andrians, All Rights Reserved *
* Licensed under MIT src: LICENCE.txt *

## Rules

# English
1. do not edit / take textures without creator permission!
2. remember. normals and speculars are mine. it also may not be edited or taken without permission of the creator
3. if there are mistakes please forgive, because I made it within a period of 4-5 days
4. if you want to give criticism and suggestions, you can contact me by email [norman25.na@gmail.com]

# 日本
1. 作成者の許可なしにテクスチャを編集/取得しないでください！
2. 覚えておいてください。 法線と鏡面反射鏡は私のものです。 また、作成者の許可なしに編集または取得することはできません
3. 間違いがある場合は4〜5日で作成しましたのでご容赦ください
4. 批判や提案をしたい場合は、メールでご連絡ください [norman25.na@gmail.com]

# Indonesia
1. jangan edit / ambil texture tanpa izin kreator!
2. ingat. normals dan speculars adalah buatanku. itu juga tidak boleh diedit ataupun di ambil tanpa ijin kreator
3. jika ada kesalahan mohon dimaafkan, karena aku membuatnya dalam kurun waktu 4 - 5 hari
4. jika kalian ingin memberi kritik dan saran, kalian bisa kontak ke email saya [norman25.na@gmail.com]

# عرب
1. لا تعدل / تأخذ زخارف بدون إذن منشئ المحتوى!
2. تذكر. الأعراف والمضاربين هم منجم. ولا يجوز تحريرها أو أخذها بدون إذن من منشئ المحتوى
3. إذا كانت هناك أخطاء ، يرجى المسامحة ، لأنني ارتكبتها في غضون 4 - 5 أيام
4. [norman25.na@gmail.com] إذا كنت ترغب في تقديم النقد والاقتراحات ، يمكنك الاتصال بي عن طريق البريد الإلكتروني
5. بالتأكيد يعلم الله كل ما تفعله

* translation is powered by Google Translate